<?php
// include_once "./config/config.php";
echo SITE_NAME;