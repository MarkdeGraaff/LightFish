<?php
class Route {
    public static $validRoutes = array();
    public static function set($route, $function) {
        self::$validRoutes[] = $route;

        //print_r(self::$validRoutes);
        if ($_GET['url'] == $route){
            $function->__invoke();
        }
        //__invoke
    }

    public static function allRoutes() {
        return self::$validRoutes;
    }

    public static function callback($use404=1){
        if (!in_array($_GET['url'], self::$validRoutes) && $use404==1){
            include_once("./app/LightFish/Error.php");
        }
    }
}