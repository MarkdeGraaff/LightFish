<?php

/*
|--------------------------------------------------------------------------
| URL to your LightFish root.
| WITH a trailing slash:
|   https://example.com/
| YOU MUST SET THIS VALUE!
| 
| If this is not set LightFish will try and guess the
| URL and due to security vulnerabilities will be
| set to $_SERVER['SERVER_ADDR'] by default if
| available.
*/
define("BASE_URL", 'http://localhost/LightFish/');

define("INDEX_PAGE", 'index.php');

define("CHARSET", "UTF-8");

define("DATE_FORMAT", 'Y-m-d H:i:s');

define("ENCRYPTION_KEY", "#L1GHTK3Y");

define('SITE_NAME', 'LightFish Framework');

define('ENVIRONMENT', 'LightFish');

define('DEBUG', true);


// Database
define('DB_HOST', 'localhost');

define('DB_NAME', 'LightFish');

define('DB_USER', 'root');

define('DB_PASS', '');
