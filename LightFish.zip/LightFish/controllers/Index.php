<?php

Class Index extends Controller  {

}
 ?>
