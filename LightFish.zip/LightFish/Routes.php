<?php

Autoloader::register();

// 1 for automatic config usage, 0 if not.

Route::set('index.php', function() {
    Index::CreateView('Index', 'php');
});

// 1 if you want to display and error page. 0 if
// you just want a blank page.
Route::callback(0);

?>